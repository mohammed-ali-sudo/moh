
# Gin + pgx + scany (v2) — Add endpoints

Services:
- services_catalog.go      (DosageForm, StrengthUnit, RouteOfAdmin, API)
- services_registry.go     (AuthHolder, MarketingAuthorization, ManufacturingSite)
- services_drug.go         (Drug, Batch, DrugAPI, DrugRegistration, DrugRegistrationSite, DrugRegistrationAuthHolder)

Handlers:
- handlers_catalog.go
- handlers_registry.go
- handlers_drug.go

All functions generate UUIDs server-side, normalize inputs, validate with shared validator,
insert with RETURNING, and scan into structs via scany v2 (pgx v5).

## Deps
go get github.com/gin-gonic/gin@latest
go get github.com/jackc/pgx/v5@latest
go get github.com/georgysavva/scany/v2@latest
go get github.com/google/uuid@latest
go mod tidy
